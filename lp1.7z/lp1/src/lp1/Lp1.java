/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lp1;
import java.util.Scanner;
import java.util.Arrays;
import java.util.Collections;
/**
 *
 * @author 119119592
 */
public class Lp1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int vetor[] = new int [10];
        int ordenador[] = new int[10];
        
        int maior_valor = 0;
        int menor_valor = 99999;
       double media = 0;
        Scanner input = new Scanner(System.in);
        for(int i=0;i < 10;i ++){
        
            System.out.println("Digite o número na posição["+i+"]:");
            vetor[i] = input.nextInt();
            if(vetor[i] > maior_valor){
                maior_valor = vetor[i];
            }
            if(vetor[i] < menor_valor){
                menor_valor = vetor[i];
            }
            media += media;
        }
        for(int i=0; i < 10;i++){
            System.out.println("O número digitado na posição["+i+"] é :" + vetor[i]);
        }
       
        
        media = media/10;
        System.out.println("===========================");
        System.out.println("O menor valor é: " + menor_valor);
        System.out.println("O maior valor é: " + maior_valor);
        System.out.println("A média dos valores digitados é : " + media);
        System.out.println("=============================");
        System.out.println("Array ordenado:");
        Arrays.sort(vetor);
        for(int i=0;i < 10;i++){
            System.out.println(vetor[i]);
            ordenador[i] = vetor[i] * -1;
        }
        System.out.println("=============================");
        System.out.println("Array em ordem descrecente:");
        Arrays.sort(ordenador);
        
         for(int i=0;i < 10;i++){
             ordenador[i] = ordenador[i] * -1;
            System.out.println(ordenador[i]);
        }
       
    }
    
}
